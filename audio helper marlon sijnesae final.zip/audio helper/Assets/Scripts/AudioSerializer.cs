﻿using System.Xml.Serialization;
using System.IO;
using UnityEngine;

//script is not important
//tesclass to see if xml stream works 
public class AudioSerializer : MonoBehaviour{

    private void Start()
    {
        AudioPlanClass audio00 = new AudioPlanClass();
        AudioPlanClass audio01 = SerializerClass.Deserialize<AudioPlanClass>("Assets/Resources/audio2.xml");


        audio00.clip = "audio1";
        audio00.volume = 1;
        
        audio00.playOnAwake = true;



        SerializerClass.Serialize(audio00, "Assets/Resources/audio2.xml");
        Debug.Log("clip: " + audio01.clip + " volume: "+ audio01.volume + " playOnAwake: "+ audio01.playOnAwake);


    }


 



}
