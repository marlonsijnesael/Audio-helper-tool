﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Text : MonoBehaviour {
    string Advertisement = "Sick and tired of the confusing mess that is called: Audio in unity? Worry no more! ";
}