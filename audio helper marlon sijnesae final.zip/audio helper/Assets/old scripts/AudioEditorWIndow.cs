﻿using System.Collections;
using System.Collections.Generic;
using System.Xml;
using UnityEngine;
using UnityEditor;

[RequireComponent (typeof(AudioPlan))]
[System.Serializable]
public class AudioEditorWIndow : EditorWindow {

    [SerializeField]
    public Object audioclip;
    public Object audioSource;
    int counter = 0;

    public int numberOfAudio = 1;
    public int numberOfAudioSource = 1 ;

    public static List<AudioClip> audioClipsList;
    public static List<Vector3> audioSourceList;


    //public static Dictionary<string, List<string>> audioSourceList;
    
    public GameObject[] objectList;
    public AudioClip[] audioList;
    public object[] SourceList;



    //scriptable object
    public AudioList listAudio_scriptable;

    [MenuItem("Window/oldFiles/AudioEditor")]
    public static void ShowWindow()
    {
        GetWindow<AudioEditorWIndow>("Audio Editor");
    }


    private void OnGUI()
    {
        


        //start window horizontally
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("load audio"))
        {
            LoadDataXML();
            CreateNewItemList();

        }
        //start object row 1 vertically 
        EditorGUILayout.BeginVertical();
                GUILayout.Label("AudioClips", EditorStyles.boldLabel);
                    if (GUILayout.Button("Add Audioclip"))
                    {
                        numberOfAudio++;
                      
                        AddItem();
                        
                    }


                    if (numberOfAudio != 0)
                    {
                        if (GUILayout.Button("delete Audioclip"))
                        {
                            numberOfAudio--;
               
            }

                    }

        KeepAudioClips();
        EditorGUILayout.EndVertical();

        //start object row 2 vertically
        EditorGUILayout.BeginVertical();    
               GUILayout.Label("AudioSources", EditorStyles.boldLabel);
                    if (GUILayout.Button("Add AudioSource"))
                    {
                        numberOfAudioSource++;
                    }


                    if (numberOfAudioSource != 0)
                    {
                        if (GUILayout.Button("delete audioSource"))
                        {
                            numberOfAudioSource--;
                        }

                    }

                    keepAudioSource();
           EditorGUILayout.EndVertical();





    }



   

    void KeepAudioClips()
    {

        //iterate through list, then add 
        int temp_count_i = 0;
        

        
        if (audioClipsList != null)
        {
            foreach (AudioClip a in audioClipsList)
            {
               temp_count_i++;
              EditorGUILayout.ObjectField(audioclip, typeof(AudioClip), true);
               // Display(key);
            }
        }
       }

  

    

    //show list of audioSources
    void keepAudioSource()
    {

        //iterate through list, then add 
        int temp_count_i = 0;



        if (audioSourceList != null)
        {
            foreach (Vector3 a in audioSourceList)
            {
                temp_count_i++;
                //EditorGUILayout.ObjectField(Vector, typeof(AudioClip), true);
                // Display(key);
            }
        }
    }


   

    //load data from xml
    void LoadDataXML()
    {

        audioClipsList = new List<AudioClip>();
        audioSourceList = new List<Vector3>();
       // audioSourceList = new Dictionary<string, List<AudioClip>>();
        
        //sets up read from xml file
        TextAsset _dataXML = (TextAsset)Resources.Load("AudioPlan");
        XmlDocument documentXML = new XmlDocument();

        documentXML.LoadXml(_dataXML.text);


        //iterates through the xml nodes
        
            foreach (XmlNode clip in documentXML["clips"].ChildNodes)
            {

                //adds to List to keep track of the audioclips
                string objName = clip.Attributes["name"].Value;
                //Vector3 pos = new Vector3().fromString(clip.Attributes["position"].Value);
                AudioClip loadClip = new AudioClip();
                loadClip = (AudioClip)Resources.Load(objName) as AudioClip;

                Vector3 pos = new Vector3();
                pos = new Vector3().fromString(clip.Attributes["position"].Value);

                audioClipsList.Add(loadClip);
                audioSourceList.Add(pos);
        }
        

      
        

                


    }

    //Create and add AudioLists
    void AddItem()
    {
        AudioPlan newItem = new AudioPlan();
        newItem.audioName = GUILayout.TextArea("name");
        newItem.audioClips = new List<AudioClip>();
        newItem.audioClips.AddRange(audioClipsList.ToArray());
        listAudio_scriptable.audioList.Add(newItem);

        int temp_count_j = 0;

        
            foreach (AudioClip a in audioClipsList)
            {
                
                newItem.audioClips[temp_count_j] = a;
                temp_count_j++; 
                //audioList[temp_count_j] = a;
        }

        int temp_count_i = 0;

            foreach(Vector3 v in audioSourceList)
        {
            newItem.audioSources[temp_count_i] = v;
            temp_count_i++;

        }
        
        
    }


    void CreateNewItemList()
    {
      
        //  viewIndex = 1;
        listAudio_scriptable = CreateAudioList.Create();
        if (listAudio_scriptable)
        {
            listAudio_scriptable.audioList = new List<AudioPlan>();
            string relPath = AssetDatabase.GetAssetPath(listAudio_scriptable);
            EditorPrefs.SetString("ObjectPath", relPath);
        }
    }




}







// audioList[audioList.Length] = new AudioClip();
//audioList[audioList.Length] = loadClip;

//  else if (audioList[0] == null)
// {
//   loadClip.name = ("clip");
// audioList[0] = new AudioClip();

/*
if (audioClipsList != null)
{
    foreach()
    {

    EditorGUILayout.ObjectField(audioclip, typeof(AudioClip), true);
    }
}
*/



