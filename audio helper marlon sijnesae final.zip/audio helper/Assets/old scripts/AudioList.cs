﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//old class
//old class no longer needed
public class AudioList : ScriptableObject {
    public List<AudioPlan> audioList = new List<AudioPlan>();
   // public List<AudioPlan> audioList = new List<AudioPlan>();
	
}
