﻿        using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;
    [System.Serializable]
    [CreateAssetMenu(fileName = "AudioData", menuName ="Audio Plan", order = 1)]

    //not important
    //old class, no longer needed;
    public class AudioPlan {

        public string audioName;
        public int currentAudio;
        public List <AudioClip> audioClips = new List<AudioClip>();
    
        public Vector3[] audioSources;

        public bool droppedDown;

    }
