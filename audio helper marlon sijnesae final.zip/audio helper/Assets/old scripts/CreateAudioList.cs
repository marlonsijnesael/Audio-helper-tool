﻿using UnityEngine;
using System.Collections;
using UnityEditor;


// not importan, old class
public class CreateAudioList
{
    [MenuItem("Assets/Create/Inventory Item List")]
    public static AudioList Create()
    {
        AudioList asset = ScriptableObject.CreateInstance<AudioList>();
        
        AssetDatabase.CreateAsset(asset, "Assets/AudioList.asset");
        AssetDatabase.SaveAssets();
        return asset;
    }
}