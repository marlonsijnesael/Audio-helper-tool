﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class FromString
{

    public static Vector3 fromString(this Vector3 vector, string value)
    {
        string[] temp = value.Replace(" ", "").Split(',');
        vector.x = float.Parse(temp[0]);
        vector.y = float.Parse(temp[1]);
        vector.z = float.Parse(temp[2]);

        return vector;
    }
}